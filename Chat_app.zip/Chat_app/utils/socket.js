/**
* Real Time chatting app
* @author Shashank Tiwari
*/
'use strict';

const path = require('path');
const helper = require('./helper');
const socketio = require('socket.io');

class Socket{

    constructor(socket){
        this.io = socket;
    }
    
    socketEvents(){

        this.io.on('connection', (socket) => {

            /**
            * get the user's Chat list
            */
            socket.on('chat-list', async (userId) => {

               let chatListResponse = {};

                if (userId === '' && (typeof userId !== 'string' || typeof userId !== 'number')) {

                    chatListResponse.error = true;
                    chatListResponse.message = `User does not exits.`;
                    
                    this.io.emit('chat-list-response',chatListResponse);
                }else{
                    const result = await helper.getChatList(userId, socket.id);
                    this.io.to(socket.id).emit('chat-list-response', {
                        error: result !== null ? false : true,
                        singleUser: false,
                        chatList: result.chatlist
                    });

                    socket.broadcast.emit('chat-list-response', {
                        error: result !== null ? false : true,
                        singleUser: true,
                        chatlist: result.userinfo
                    });
                }
            });
            /**
            * send the messages to the user
            */
            socket.on('add-message', async (data) => {
                
                if (data.message === '') {
                    
                    this.io.to(socket.id).emit(`alert-response`,`Message cant be empty`); 

                }else if(data.fromUserId === ''){
                    
                    this.io.to(socket.id).emit(`alert-response`,`Unexpected error, Login again.`); 

                }else if(data.toUserId === ''){
                    
                    this.io.to(socket.id).emit(`alert-response`,`Select a user to chat.`); 

                }else{
                    let toSocketId = data.toSocketId;
                    const sqlResult = await helper.insertMessages({
                        fromUserId: data.fromUserId,
                        toUserId: data.toUserId,
                        message: data.message,
                        date:data.date,
                        replyfrom:data.replyfrom,
                        replymsg:data.replymsg
                    });
                    if(data.online=='G')
                    {
                        this.io.to("group"+data.toUserId).emit('add-message-response',data);
                        return;
                    }
                    if(toSocketId!==null)
                        this.io.to(toSocketId).emit(`add-message-response`, data); 
                }               
            });

            /**
            * Add Friend
            */
           socket.on('add-friend', async (data) => {
                var result = await helper.getdata({ name: data.to});
                if(!result[0])
                        return
                data.to=result[0].id;
                if(data.from==data.to)
                        return;
                var count = await helper.alreadyFriend({ from: data.from, to: data.to});
                if(count[0].co>0)
                {
                    this.io.to(socket.id).emit(`alert-response`,`Already a freind`);
                    return;
                }
                const addResult = await helper.insertFriend({ from: data.from, to: data.to});
                this.io.to(socket.id).emit(`chat-list-response`,{
                        error: result !== null ? false : true,
                        addUser: true,
                        chatlist: result[0]
                    });
            });
            
            /**
            * New Group
            */
            socket.on('new-group', async (data) => {
                let gid=await helper.new_group(data.username);
                var grpid=gid[0].count;
                var result=[];

                for(var member of data.members)
                {
                    result = await helper.insertFriend({from: member.id,to:grpid});
                    if(member.socketid && member.socketid!="")
                    {
                        this.io.to(member.socketid).emit(`chat-list-response`,{
                                error: result !== null ? false : true,
                                addUser: true,
                                chatlist: {id:grpid,username:data.username,online:'G',members:data.members}
                        });
                    }
                }
                this.io.to(socket.id).emit(`chat-list-response`,{
                        error: result !== null ? false : true,
                        addUser: true,
                        chatlist: {id:grpid,username:data.username,online:'G',members:data.members}
                });
            });
            /*
             * Join Group
             */
            socket.on('join-group', async (id) => {
                socket.join("group"+id);
            });
            /**
            * Logout the user
            */
            socket.on('logout', async () => {
                const isLoggedOut = await helper.logoutUser(socket.id);
                this.io.broadcast.to(socket.id).emit('logout-response',{
                    error : false
                });
                socket.disconnect();
            });


            /**
            * sending the disconnected user to all socket users. 
            */
            socket.on('disconnect',async ()=>{
                const isLoggedOut = await helper.logoutUser(socket.id);
                setTimeout(async ()=>{
                    const isLoggedOut = await helper.isUserLoggedOut(socket.id);
                    if (isLoggedOut && isLoggedOut !== null) {
                        socket.broadcast.emit('chat-list-response', {
                            error: false,
                            userDisconnected: true,
                            socketid: socket.id
                        });
                    }
                },1000);
            });

        });
    }
    
    socketConfig(){

        this.io.use( async (socket, next) => {
            let userId = socket.request._query['userId'];
            let userSocketId = socket.id;          
            const response = await helper.addSocketId( userId, userSocketId);
            if(response &&  response !== null){
                next();
            }else{
                console.error(`Socket connection failed, for  user Id ${userId}.`);
            }
        });

        this.socketEvents();
    }
}
module.exports = Socket;