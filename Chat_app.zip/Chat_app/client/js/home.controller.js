'user strict';
app.controller('homeController', function ($scope,$sce, $routeParams, $location, appService){
    
    const UserId = $routeParams.userId;
	$scope.userid=UserId;
    $scope.reply = {
        isreply:false,
        replymsg:null,
        replyfrom:null
    };
    $scope.group={
        new:false,
        name:null,
        member_name:null,
        members:[]
    };
    $scope.data = {
        username: '',
        chatlist: [],
        selectedFriendId: null,
        selectedFriendName: null,
        selectedFriendOnline: null,
        members: [],
        messages: []
    };
    appService.connectSocketServer(UserId);
    appService.httpCall({
        url: '/userSessionCheck',
        params: {
            'userId': UserId
        }
    })
    .then((response) => {
        $scope.data.username = response.username;
        appService.socketEmit(`chat-list`, UserId);
        appService.socketOn('chat-list-response', (response) => {
            $scope.$apply( () =>{
                if (!response.error) {
                    if (response.addUser) {
                        /*
                        * add user
                        */
                       if(response.chatlist.online=='G')
                       {
                           appService.socketEmit(`join-group`,response.chatlist.id);
                       }
                       $scope.data.chatlist.push(response.chatlist);
                       
                    } else if (response.singleUser) {
                        /*
                        * make online
                        */
                       var n = $scope.data.chatlist.length;
                       for(var i=0;i<n;i++)
                       {
                           if($scope.data.chatlist[i].id===response.chatlist.id)
                           {
                               $scope.data.chatlist[i].socketid=response.chatlist.socketid;
                               $scope.data.chatlist[i].online="Y";
                           }
                       }
                       
                    } else if (response.userDisconnected) {
                        /*
                        * make offline
                        */
                       var n = $scope.data.chatlist.length;
                       for(var i=0;i<n;i++)
                       {
                           if($scope.data.chatlist[i].socketid===response.socketid)
                           {
                               $scope.data.chatlist[i].socketid="";
                               $scope.data.chatlist[i].online="N";
                           }
                       }
                    } else {
                        /* 
                        * Updating entire chatlist if user logs in
                        */
                          $scope.data.chatlist = response.chatList;
                          for(var user of $scope.data.chatlist)
                          {
                              if(user.online=='G')
                              {
                                  appService.socketEmit(`join-group`,user.id);
                              }
                          }
                    }
                } else {
                    alert(`Faild to load Chat list`);
                }
            });
        });

        /*
        * This eventt will display the new incmoing message
        */
        appService.socketOn('add-message-response', (response) => {
            $scope.$apply( () => {
                if (response && response.fromUserId == $scope.data.selectedFriendId || (response.online=='G' && response.toUserId == $scope.data.selectedFriendId && response.fromUserId!= UserId )) {
                    $scope.data.messages.push(response);
                    appService.scrollToBottom();
                }
            });
        });      
    })
    .catch((error) => {
        console.log(error.message);
        $scope.$apply( () =>{
            $location.path(`/`);
        });
    });


    $scope.selectFriendToChat = (friendId) => {
        /*
        * Highlighting the selected user from the chat list
        */
        const friendData = $scope.data.chatlist.filter((obj) => {
            return obj.id === friendId;
        });
        $scope.data.selectedFriendName = friendData[0]['username'];
        $scope.data.selectedFriendOnline = friendData[0]['online'];
        $scope.data.selectedFriendId = friendId;
        $scope.data.members = [];
        /**
        * This HTTP call will fetch chat between two users
        */
        appService.getMessages(UserId, friendId,$scope.data.selectedFriendOnline).then( (response) => {
                $scope.$apply(() => {
                    $scope.data.messages = response.messages;
                    if($scope.data.selectedFriendOnline=='G')
                        $scope.data.members = response.members;
                });
                appService.scrollToBottom();
            }).catch( (error) => {
                console.log(error);
                alert('Unexpected Error, Contact your Site Admin.');
            });
            $scope.reply.isreply=false;
        document.getElementById("message").focus();
        document.getElementById("message").select();
    };
    $scope.sendMessage1 = (event) =>
    {
        if(event.keyCode===13)
        {
            if(event.shiftKey===false)
            {
                $scope.sendMessage();
            }
        }
    };
    $scope.sendMessage = () => {

            let toUserId = null;
            let toSocketId = null;
            /* Fetching the selected User from the chat list starts */
            let selectedFriendId = $scope.data.selectedFriendId;
            if (selectedFriendId === null) {
                return null;
            }
            friendData = $scope.data.chatlist.filter((obj) => {
                return obj.id === selectedFriendId;
            });
            /* Fetching the selected User from the chat list ends */
            
            /* Emmiting socket event to server with Message, starts */
            if (friendData.length > 0) {

                toUserId = friendData[0]['id'];
                if(friendData[0]['online']==='N')
                    toSocketId=null;
                else
                    toSocketId = friendData[0]['socketid'];
                var d=new Date();
                var dt=("0"+(d.getHours())).slice(-2)+":"+("0"+(d.getMinutes())).slice(-2)+"  "+("0"+(d.getDate())).slice(-2)+"/"+("0"+(d.getMonth()+1)).slice(-2);
                
                
                if($scope.reply.isreply!==true)
                {
                    messagePacket = {
                    message: document.querySelector('#message').value,
                    fromUserId: UserId,
                    toUserId: toUserId,
                    toSocketId: toSocketId,
                    date:dt,
                    replyfrom:null,
                    replymsg:null,
                    online:friendData[0]['online']                    
                    };
                }
                else
                {
                    refr=$scope.reply.replyfrom;
                    messagePacket = {
                    message: document.querySelector('#message').value,
                    fromUserId: UserId,
                    toUserId: toUserId,
                    toSocketId: toSocketId,
                    date:dt,
                    replyfrom:$scope.reply.replyfrom,
                    replymsg:$scope.reply.replymsg,
                    online:friendData[0]['online']   
                    };
                }
                if(messagePacket.message.length===0||messagePacket.message==="\n")
                {
                    document.querySelector('#message').value =null;
                    return null;
                }
                $scope.data.messages.push(messagePacket);
                appService.socketEmit(`add-message`, messagePacket);



                document.querySelector('#message').value =null;
                appService.scrollToBottom();
            }else {
                alert('Unexpected Error Occured,Please contact Admin');
            }
            /* Emmiting socket event to server with Message, ends */
            $scope.reply.isreply=false;
        
    };

    $scope.addFriend = (event) => {

        if (event.keyCode === 13) {
            
            fid = document.querySelector('#friend').value;
            document.querySelector('#friend').value = '';
            let friends = {
                    from: UserId,
                    to: fid
                };
            appService.socketEmit(`add-friend`, friends);
        }
    };
    
    $scope.alignMessage = (fromUserId) => {
        return fromUserId === UserId ? true : false;
    };

    $scope.logout = () => {
        appService.socketEmit(`logout`, UserId);
        $location.path(`/`);
    };
    
    $scope.clean =(msg) =>
    {
        return $sce.trustAsHtml(msg);
    };
    
    $scope.doreply =(index) =>
    {
        $scope.reply.isreply=true;
        $scope.reply.replymsg=$scope.data.messages[index].message;
        $scope.reply.replyfrom=$scope.data.messages[index].fromUserId;
        window.getSelection().removeAllRanges();
        document.getElementById("message").focus();
        document.getElementById("message").select();
    };
    $scope.reply_name =(index) =>
    {
        if(UserId==index)
            return "you";
        if($scope.data.selectedFriendOnline=='G')
        {
            var member=$scope.data.members.filter((obj)=>{return index==obj.id});
            return member[0].username;
        }
        return $scope.data.selectedFriendName;
    };
    $scope.reply_cancel =() =>
    {
        $scope.reply.isreply=false;
        $scope.reply.replymsg=null;
        $scope.reply.replyfrom=null;
    };
    
    $scope.new_group_add_member1 =(event) =>
    {
        if(event.keyCode==13)
            $scope.new_group_add_member();
    };
    $scope.new_group_add_member =() =>
    {
        if($scope.group.member_name==null)
            return;
        var mem=$scope.data.chatlist.filter((obj)=>{ return obj.username==$scope.group.member_name});
        if(mem[0])
        {
            $scope.group.members.push(mem[0]);
            $scope.group.member_name=null;
        }
        else
        {
            alert("Username not fount in your Friends");
        }
    };
    $scope.new_group_create =() =>
    {
        if($scope.group.name==null || $scope.group.name.length<1)
        {
            alert("Group Name is not valid");
            $scope.group.name=null;
            return;
        }
        if($scope.group.members.length<2)
        {
            alert("Group members must be more than or equal to 3");
            return;
        }
        let group=
        {
            username: $scope.group.name,
            members : $scope.group.members.map(function(obj) {return {id:obj.id,socketid:obj.socketid};})
        };
        group.members.push({id:UserId,socketid:null});
        appService.socketEmit(`new-group`, group);
		$scope.new_group_cancel();
    };
    $scope.new_group_cancel =() =>
    {
        $scope.group.new=false;
        $scope.group.name=null;
        $scope.group.members=[];
    };
    $scope.member_unselect =(index) =>
    {
        $scope.group.members.splice(index,1);
    };
    $scope.hide =() =>
    {
        $scope.group.new=false;
    };
});